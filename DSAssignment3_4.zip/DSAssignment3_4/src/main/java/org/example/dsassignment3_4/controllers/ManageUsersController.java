package org.example.dsassignment3_4.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;

import org.example.dsassignment3_4.dao.DBConnection;
import org.example.dsassignment3_4.model.User;
import org.example.dsassignment3_4.service.UserService;

import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

public class ManageUsersController implements Initializable {

    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private TextField emailField;
    @FXML
    private DatePicker dobField;
    @FXML
    private ComboBox<String> genderComboBox;
    @FXML
    private Label statusLabel;

    @FXML
    private TableView<User> usersTable;
    @FXML
    private TableColumn<User,Integer> idColumn;
    @FXML
    private TableColumn<User, String> usernameColumn;
    @FXML
    private TableColumn<User, String> emailColumn;
    @FXML
    private TableColumn<User, String> dobColumn;
    @FXML
    private TableColumn<User, String> genderColumn;
//    @FXML
//    private TableColumn<User, String> passwordColumn;


    public void loadUserData() {
        ObservableList<User> userList = FXCollections.observableArrayList();
        UserService userService = new UserService();

        try {
            // Load users from the database
            List<User> users = userService.loadData();
            userList.addAll(users);

            // Bind data to the table
            usersTable.setItems(userList);

            // Configure table columns to display user properties\
            idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
            usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
            emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
            dobColumn.setCellValueFactory(new PropertyValueFactory<>("dob"));
            genderColumn.setCellValueFactory(new PropertyValueFactory<>("gender"));
//            passwordColumn.setCellValueFactory(new PropertyValueFactory<>("password"));
        } catch (SQLException e) {
            e.printStackTrace();
            setStatus("Failed to load user data.", Color.RED);
        }
    }


    @FXML
    private void handleRegister() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        String email = emailField.getText();
        String dob = dobField.getValue() != null ? dobField.getValue().toString() : "";
        String gender = genderComboBox.getValue();

        // Input validations
        if (username.isEmpty() || password.isEmpty() || email.isEmpty() || dob.isEmpty() || gender == null) {
            setStatus("Please fill in all fields.", Color.RED);
            return;
        }

        if (password.length() < 5) {
            setStatus("Password must be at least 5 characters.", Color.RED);
            return;
        }

        if (!isUsernameUnique(username)) {
            setStatus("Username already exists.", Color.RED);
            return;
        }

        if (!isValidEmail(email)) {
            setStatus("Invalid email format.", Color.RED);
            return;
        }

        if (!isValidDOB(LocalDate.parse(dob))) {
            setStatus("You must be at least 13 years old to register.", Color.RED);
            return;
        }


        // Store user data in both tables
        try{
            Connection conn = DBConnection.getConnection();
            String userInsertQuery = "INSERT INTO users (username, password) VALUES (?, SHA2(?, 256))";
            PreparedStatement pstmt1 = conn.prepareStatement(userInsertQuery);
            pstmt1.setString(1, username);
            pstmt1.setString(2, password);
            pstmt1.executeUpdate();

            conn = DBConnection.getConnection();
            String query = "SELECT id FROM users WHERE username = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            int id =0;
            if(rs.next()){
                id = rs.getInt(1);
            }

            String userInfoInsertQuery = "INSERT INTO userinfo (user_id, email, dob, gender) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt2 = conn.prepareStatement(userInfoInsertQuery);
            pstmt2.setInt(1,id);
            pstmt2.setString(2, email);
            pstmt2.setString(3, dob);
            pstmt2.setString(4, gender);
            pstmt2.executeUpdate();

            setStatus("Registration successful.", Color.GREEN);
            loadUserData();
            clear();

        } catch (SQLException e) {
            e.printStackTrace();
            setStatus("Registration failed due to a database error.", Color.RED);
        }
    }

    private boolean isUsernameUnique(String username) {
        try  {
            Connection conn = DBConnection.getConnection();
            String query = "SELECT username FROM users WHERE username = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            return !rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            setStatus("Error checking username uniqueness.", Color.RED);
            return false;
        }
    }

    private void setStatus(String message, Color color) {
        statusLabel.setText(message);
        statusLabel.setTextFill(color);
    }

    // Utility method to check email format
    private boolean isValidEmail(String email) {
        String emailRegex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        Pattern pattern = Pattern.compile(emailRegex);
        return pattern.matcher(email).matches();
    }

    // Utility method to check DOB
    private boolean isValidDOB(LocalDate dob) {
        LocalDate today = LocalDate.now();
        if (dob.isAfter(today)) {
            return false; // Future date not allowed
        }
        int age = Period.between(dob, today).getYears();
        return age >= 13;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<String> choices = FXCollections.observableArrayList("Male", "Female");
        genderComboBox.setItems(choices);
        loadUserData();
        setupTableListener();
    }

    void setupTableListener(){
        usersTable.getSelectionModel().selectedItemProperty().addListener((observable , oldValue , newValue)->{
            if(newValue!=null){
                User selectedUser = newValue;
                statusLabel.setText("usedId: "+selectedUser.getId()+" is selected!");
                usernameField.setText(selectedUser.getUsername());
                emailField.setText(selectedUser.getEmail());
                passwordField.setText(selectedUser.getPassword());
                dobField.setValue(LocalDate.parse(selectedUser.getDob().toString()));
                genderComboBox.setValue(selectedUser.getGender());
            }
        });
    }

    private void handleDelete(){
        String username = usernameField.getText();
        if (username.isEmpty()) {
            setStatus("Please enter a username.", Color.RED);
            return;
        }

        if (!isUsernameUnique(username)) {
            try {
                Connection conn = DBConnection.getConnection();
                String query = "DELETE FROM users WHERE username = ?";
                PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setString(1, username);
                pstmt.executeUpdate();
                setStatus("User deleted successfully.", Color.GREEN);
            } catch (SQLException e) {
                e.printStackTrace();
                setStatus("Failed to delete user.", Color.RED);
            }
        } else {
            setStatus("User does not exist.", Color.RED);
        }
    }

    private void handleUpdate(){
        String username = usernameField.getText();
        String password = passwordField.getText();
        String email = emailField.getText();
        String dob = dobField.getValue() != null ? dobField.getValue().toString() : "";

        if (username.isEmpty() || password.isEmpty() || email.isEmpty() || dob.isEmpty()) {
            setStatus("Please fill in all fields.", Color.RED);
            return;
        }

            try {
                Connection conn = DBConnection.getConnection();
                String query = "UPDATE users SET password = ? WHERE username = ?";
                PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setString(1, password);
                pstmt.setString(2, username);
                pstmt.executeUpdate();

                conn = DBConnection.getConnection();
                query = "SELECT id FROM users WHERE username = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, username);
                ResultSet rs = pstmt.executeQuery();
                int id =0;
                if(rs.next()){
                    id = rs.getInt(1);
                }

                query = "UPDATE userinfo SET email = ?, dob = ? WHERE user_id=?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, email);
                pstmt.setDate(2, Date.valueOf(dob));
                pstmt.setInt(3,id);
                pstmt.executeUpdate();

                setStatus("User updated successfully.", Color.GREEN);
            } catch (SQLException e) {
                e.printStackTrace();
                setStatus("Failed to update user.", Color.RED);
            }

    }

    public void updateUserRecord(){
        handleUpdate();
    }
    public void deleteUserRecord(){
        handleDelete();
    }

    public void clear(){
        usernameField.clear();
        passwordField.clear();
        emailField.clear();
        dobField.getEditor().clear();
        statusLabel.setText("");
    }

    public void addUserRecord(){
        handleRegister();
    }

}
