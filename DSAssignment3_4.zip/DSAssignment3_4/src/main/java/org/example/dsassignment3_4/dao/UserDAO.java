package org.example.dsassignment3_4.dao;

import org.example.dsassignment3_4.model.SuggestedFriend;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    public static List<SuggestedFriend> getSuggestedFriends(int userId) {
        List<SuggestedFriend> suggestedFriends = new ArrayList<>();
        String query = """
            SELECT
                u.id AS suggested_friend_id,
                u.username,
                COUNT(f2.user2_id) AS mutual_friends,
                (CASE WHEN cp1.hobbies = cp2.hobbies THEN 1 ELSE 0 END) AS shared_hobbies,
                (CASE WHEN cp1.location = cp2.location THEN 1 ELSE 0 END) AS location_match,
                (CASE WHEN ABS(cp1.age - cp2.age) <= 5 THEN 1 ELSE 0 END) AS age_proximity,
                (0.5 * COUNT(f2.user2_id)
                 + 0.3 * (CASE WHEN cp1.hobbies = cp2.hobbies THEN 1 ELSE 0 END)
                 + 0.2 * ((CASE WHEN cp1.location = cp2.location THEN 1 ELSE 0 END)
                          + (CASE WHEN ABS(cp1.age - cp2.age) <= 5 THEN 1 ELSE 0 END))) AS score
            FROM
                users u
            LEFT JOIN
                friendships f1 ON (f1.user1_id = ? AND f1.user2_id = u.id)
            LEFT JOIN
                friendships f2 ON (f2.user1_id = ? AND f2.user2_id = f1.user2_id)
            LEFT JOIN
                completeProfile cp1 ON cp1.user_id = ?
            LEFT JOIN
                completeProfile cp2 ON cp2.user_id = u.id
            WHERE\s
                u.id != ?
                AND f1.user2_id IS NULL
            GROUP BY
                u.id
            ORDER BY
                score DESC
            LIMIT 5;
        """;

        try {Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);

            stmt.setInt(1, userId);
            stmt.setInt(2, userId);
            stmt.setInt(3, userId);
            stmt.setInt(4, userId);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {

                SuggestedFriend friend = new SuggestedFriend(
                    rs.getInt("suggested_friend_id"),
                    rs.getString("username"),
                    rs.getDouble("score")

                );

                suggestedFriends.add(friend);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return suggestedFriends;
    }

    public static List<SuggestedFriend> getSuggestedFriend(int userId) {
        List<SuggestedFriend> suggestedFriends = new ArrayList<>();
        String sql = "SELECT\n" +
                "    u.id AS suggested_friend_id,\n" +
                "    u.username,\n" +
                "    COUNT(f2.user2_id) AS mutual_friends,\n" +
                "    MAX(MAX_COUNT.friends_count) AS max_mutual_friends,\n" + // Use MAX to aggregate friends_count
                "    (COUNT(f2.user2_id) / MAX(MAX_COUNT.friends_count)) AS normalized_mutual_friends,\n" + // Use MAX() here
                "    (CASE WHEN cp1.hobbies = cp2.hobbies THEN 1 ELSE 0 END) AS shared_hobbies,\n" +
                "    (CASE WHEN cp1.location = cp2.location THEN 1 ELSE 0 END) AS location_match,\n" +
                "    (CASE WHEN ABS(cp1.age - cp2.age) <= 5 THEN 1 ELSE 0 END) AS age_proximity,\n" +
                "    (CASE WHEN cp1.education = cp2.education THEN 1 ELSE 0 END) AS education_match,\n" +
                "    (\n" +
                "        (0.5 * (COUNT(f2.user2_id) / MAX(MAX_COUNT.friends_count))) +\n" + // Use MAX() here as well
                "        (0.2 * (CASE WHEN cp1.hobbies = cp2.hobbies THEN 1 ELSE 0 END)) +\n" +
                "        (0.1 * (CASE WHEN cp1.location = cp2.location THEN 1 ELSE 0 END)) +\n" +
                "        (0.1 * (CASE WHEN ABS(cp1.age - cp2.age) <= 5 THEN 1 ELSE 0 END)) +\n" +
                "        (0.1 * (CASE WHEN cp1.education = cp2.education THEN 1 ELSE 0 END))\n" +
                "    ) AS score\n" +
                "FROM\n" +
                "    users u\n" +
                "LEFT JOIN\n" +
                "    friendships f1 ON f1.user1_id = ? AND f1.user2_id = u.id\n" +
                "LEFT JOIN\n" +
                "    friendships f2 ON f2.user1_id = ? AND f2.user2_id = f1.user2_id\n" +
                "LEFT JOIN\n" +
                "    completeProfile cp1 ON cp1.user_id = ?\n" +
                "LEFT JOIN\n" +
                "    completeProfile cp2 ON cp2.user_id = u.id\n" +
                "LEFT JOIN\n" +
                "    (\n" +
                "        SELECT MAX(friends_count) AS friends_count\n" +
                "        FROM (\n" +
                "            SELECT COUNT(f2.user2_id) AS friends_count\n" +
                "            FROM friendships f1\n" +
                "            LEFT JOIN friendships f2 ON f2.user1_id = f1.user2_id\n" +
                "            WHERE f1.user1_id = ?\n" +
                "            GROUP BY f1.user2_id\n" +
                "        ) AS subquery\n" +
                "    ) AS MAX_COUNT ON 1 = 1\n" +
                "WHERE\n" +
                "    u.id != ?\n" +
                "    AND f1.user2_id IS NULL\n" +
                "GROUP BY\n" +
                "    u.id\n" +
                "ORDER BY\n" +
                "    score DESC\n" +
                "LIMIT 10;\n";

        try {Connection conn = DBConnection.getMySQLConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, userId);
            stmt.setInt(2, userId);
            stmt.setInt(3, userId);
            stmt.setInt(4, userId);
            stmt.setInt(5, userId);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                SuggestedFriend friend = new SuggestedFriend(
                        rs.getInt("suggested_friend_id"),
                        rs.getString("username"),
                        rs.getDouble("score")
                );
                suggestedFriends.add(friend);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return suggestedFriends;
    }

    public static void main(String[] args) {
        UserDAO dao = new UserDAO();
        System.out.println(getSuggestedFriends(5));

    }
}
