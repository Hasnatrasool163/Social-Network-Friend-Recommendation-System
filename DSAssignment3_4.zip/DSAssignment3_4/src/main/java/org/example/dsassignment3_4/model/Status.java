package org.example.dsassignment3_4.model;

    public enum Status {
        PENDING,
        ACCEPTED,
        DECLINED
    }

