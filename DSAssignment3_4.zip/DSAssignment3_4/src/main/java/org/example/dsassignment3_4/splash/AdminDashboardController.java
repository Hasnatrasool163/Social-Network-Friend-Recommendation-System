package org.example.dsassignment3_4.splash;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.util.HashMap;
import java.util.Map;

public class AdminDashboardController {

    @FXML
    private ListView<String> userListView;

    @FXML
    private Canvas graphCanvas;

    @FXML
    private Button showConnectionsButton;

    @FXML
    private Button addUserButton;

    @FXML
    private TextField userNameField;

    private Map<String, String[]> userConnections = new HashMap<>();

    private ObservableList<String> users = FXCollections.observableArrayList();

    private double[] nodePositions = new double[2];

    public void initialize() {
        userListView.setItems(users);
        showConnectionsButton.setOnAction(this::showConnections);
        addUserButton.setOnAction(this::addUser);
        graphCanvas.setOnMouseDragged(this::dragNode);
    }

    private void showConnections(ActionEvent event) {
        // Clear previous drawings
        GraphicsContext gc = graphCanvas.getGraphicsContext2D();
        gc.clearRect(0, 0, graphCanvas.getWidth(), graphCanvas.getHeight());

        // Draw connections
        for (String user : users) {
            drawUser(gc, user, 250, 200);
            String[] friends = userConnections.get(user);
            if (friends != null) {
                for (String friend : friends) {
                    drawUser(gc, friend, 300, 300);
                    gc.setStroke(Color.WHITE);
                    gc.setLineWidth(2);
                    gc.strokeLine(250, 200, 300, 300);
                }
            }
        }
    }

    private void addUser(ActionEvent event) {
        String userName = userNameField.getText();
        if (!userName.isEmpty()) {
            users.add(userName);
            userNameField.clear();
        }
    }

    private void drawUser(GraphicsContext gc, String user, double x, double y) {
        gc.setFill(Color.ORANGE);
        gc.fillOval(x - 20, y - 20, 40, 40);
        gc.setFill(Color.BLACK);
        gc.setFont(new Font(16));
        gc.fillText(user, x - 20, y + 30);
    }

    private void dragNode(MouseEvent event) {
        nodePositions[0] = event.getX();
        nodePositions[1] = event.getY();
        GraphicsContext gc = graphCanvas.getGraphicsContext2D();
        gc.clearRect(0, 0, graphCanvas.getWidth(), graphCanvas.getHeight());
        for (String user : users) {
            drawUser(gc, user, nodePositions[0], nodePositions[1]);
        }
    }
}