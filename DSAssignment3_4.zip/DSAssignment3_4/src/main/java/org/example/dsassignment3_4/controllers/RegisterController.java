package org.example.dsassignment3_4.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import org.example.dsassignment3_4.dao.DBConnection;
import org.example.dsassignment3_4.utilities.UtilityMethods;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class RegisterController implements Initializable {

    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private TextField emailField;
    @FXML
    private DatePicker dobField;
    @FXML
    private ComboBox<String> genderComboBox;
    @FXML
    private Label statusLabel;

    @FXML
    private void handleRegister() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        String email = emailField.getText();
        String dob = dobField.getValue() != null ? dobField.getValue().toString() : "";
        String gender = genderComboBox.getValue();

        // Input validations
        if (username.isEmpty() || password.isEmpty() || email.isEmpty() || dob.isEmpty() || gender.isBlank() || gender.isEmpty()) {
            setStatus("Please fill in all fields.", Color.RED);
            return;
        }

        if (password.length() < 8) {
            setStatus("Password must be at least 8 characters.", Color.RED);
            return;
        }

        if (!isUsernameUnique(username)) {
            setStatus("Username already exists.", Color.RED);
            return;
        }

        if (!isValidEmail(email)) {
            setStatus("Invalid email format.", Color.RED);
            return;
        }

        if (!isValidDOB(LocalDate.parse(dob))) {
            setStatus("You must be at least 13 years old to register.", Color.RED);
            return;
        }


        // Store user data in both tables
        try{
            Connection conn = DBConnection.getConnection();
            String userInsertQuery = "INSERT INTO users (username, password) VALUES (?, ?)";
            PreparedStatement pstmt1 = conn.prepareStatement(userInsertQuery);
            pstmt1.setString(1, username);
            pstmt1.setString(2, password);
            pstmt1.executeUpdate();

            conn = DBConnection.getConnection();
            String query = "SELECT id FROM users WHERE username = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            int id =0;
            if(rs.next()){
                id = rs.getInt(1);
            }

            String userInfoInsertQuery = "INSERT INTO userinfo (user_id, email, dob, gender) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt2 = conn.prepareStatement(userInfoInsertQuery);
            pstmt2.setInt(1,id);
            pstmt2.setString(2, email);
            pstmt2.setString(3, dob);
            pstmt2.setString(4, gender);
            pstmt2.executeUpdate();

            setStatus("Registration successful.", Color.GREEN);
            switchToLoginScene();
        } catch (SQLException e) {
            e.printStackTrace();
            setStatus("Registration failed due to a database error.", Color.RED);
        }
    }

    private boolean isUsernameUnique(String username) {
        try  {
            Connection conn = DBConnection.getConnection();
            String query = "SELECT username FROM users WHERE username = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            return !rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            setStatus("Error checking username uniqueness.", Color.RED);
            return false;
        }
    }

    private void setStatus(String message, Color color) {
        statusLabel.setText(message);
        statusLabel.setTextFill(color);
    }

    private boolean isValidEmail(String email) {
        return UtilityMethods.isValidEmail(email);
    }

    private boolean isValidDOB(LocalDate dob) {
        return UtilityMethods.isValidDOB(dob);
    }

    @FXML
    private void switchToLoginScene() {
      UtilityMethods.switchToScene(usernameField,"Login");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<String> choices ;
        choices = FXCollections.observableArrayList();
        choices.add("Male");
        choices.add("Female");
        genderComboBox.setItems(choices);
    }
}
