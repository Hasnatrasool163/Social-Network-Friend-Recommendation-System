package org.example.dsassignment3_4.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import org.example.dsassignment3_4.dao.DBConnection;
import org.example.dsassignment3_4.service.SessionManager;
import org.example.dsassignment3_4.utilities.UtilityMethods;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private TextField emailField;
    @FXML
    private DatePicker dobField;
    @FXML
    private ComboBox<String> genderComboBox;
    @FXML
    private Label statusLabel;
    @FXML
    private Button switchButton;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        checkServerConnection();
    }

    private void checkServerConnection() {
        try {
            Connection conn = DBConnection.getConnection();
            if (conn != null && !conn.isClosed()) {
                statusLabel.setTextFill(Color.GREEN);
                setStatus("Connected to server.", Color.GREEN);
            } else {
                setStatus("Failed to connect to server.", Color.RED);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            setStatus("Error checking server connection.", Color.RED);
        }
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            setStatus("Please fill in all fields.", Color.RED);
            return;
        }

        try  {
            Connection conn = DBConnection.getConnection();
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                if(rs.getInt("is_admin")==1){
                    setStatus("Welcome Admin.", Color.GREEN);
                    UtilityMethods.showPopup("Welcome : "+username);
                    switchScene("AdminDashboard");
                    return;
                }
                setStatus("Login successful.", Color.GREEN);
                UtilityMethods.showPopup("Welcome : "+username);
                int id = rs.getInt("id");
                SessionManager.getInstance().setUserId(id);
                SessionManager.getInstance().setUsername(username);
                SessionManager.getInstance().setStatus(1);
                System.out.println(username + "is logged in!"+ "has id " + id);
                switchScene("Dashboard");

            } else {
                setStatus("Invalid username or password.", Color.RED);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            setStatus("Database error occurred.", Color.RED);
        }
    }

    public void switchToRegisterScene() {
        UtilityMethods.switchToScene(switchButton,"Register");

    }

    void switchScene(String fxmlFile){
      UtilityMethods.switchToScene(switchButton,fxmlFile);
    }

    public void showForgetPasswordScene(){
       UtilityMethods.switchToScene("ForgetPassword");
    }

    private void setStatus(String message, Color color) {
        statusLabel.setText(message);
        statusLabel.setTextFill(color);
    }
}
