package org.example.dsassignment3_4.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GraphController {

    @FXML
    private Pane graphPane;

    @FXML
    private Button addFriendButton;

    @FXML
    private Button removeFriendButton;

    @FXML
    private Button refreshButton;

    private final List<Circle> friendNodes = new ArrayList<>();
    private final List<Text> friendNames = new ArrayList<>();
    private final List<Line> connections = new ArrayList<>();
    private final Random random = new Random();

    @FXML
    public void initialize() {
        System.out.println("Graph initialized!");
        addPresetUsers();
    }

    private void addPresetUsers() {
        // Manually adding a few users and connections for demo purposes
        Circle user1 = createUserNode(100, 100, "#4CAF50", "User 1");
        Circle user2 = createUserNode(300, 100, "#2196F3", "User 2");
        Circle user3 = createUserNode(500, 100, "#FF5722", "User 3");
        createConnection(user1, user2);
        createConnection(user2, user3);
    }

    private Circle createUserNode(double x, double y, String color, String name) {
        Circle user = new Circle(x, y, 20);
        user.setFill(javafx.scene.paint.Color.web(color));
        user.setUserData(name);

        Text userName = new Text(x - 15, y + 30, name);
        graphPane.getChildren().add(userName);
        graphPane.getChildren().add(user);
        friendNodes.add(user);
        friendNames.add(userName);
        return user;
    }

    private void createConnection(Circle user1, Circle user2) {
        Line connection = new Line(user1.getCenterX(), user1.getCenterY(),
                user2.getCenterX(), user2.getCenterY());
        connection.setStrokeWidth(2);
        connection.setStroke(javafx.scene.paint.Color.GRAY);
        graphPane.getChildren().add(connection);
        connections.add(connection);
    }

    @FXML
    private void handleAddFriend() {
        double x = random.nextDouble() * (graphPane.getWidth() - 40) + 20;
        double y = random.nextDouble() * (graphPane.getHeight() - 40) + 20;
        Circle newFriend = createUserNode(x, y, getRandomColor(), "User " + (friendNodes.size() + 1));

        makeNodeDraggable(newFriend);

        if (friendNodes.size() > 1) {
            Circle previousFriend = friendNodes.get(friendNodes.size() - 2);
            createConnection(previousFriend, newFriend);
        }
    }

    @FXML
    private void handleRemoveFriend() {
        if (!friendNodes.isEmpty()) {
            Circle lastFriend = friendNodes.removeLast();
            Text lastFriendName = friendNames.removeLast();
            graphPane.getChildren().remove(lastFriend);
            graphPane.getChildren().remove(lastFriendName);


            if (!connections.isEmpty()) {
                Line lastConnection = connections.removeLast();
                graphPane.getChildren().remove(lastConnection);
            }
        }
    }

    @FXML
    private void handleRefresh() {
        System.out.println("Refresh button clicked!");
        graphPane.getChildren().clear();
        friendNodes.clear();
        connections.clear();
        addPresetUsers();
    }

    private void makeNodeDraggable(Circle node) {
        node.setOnMousePressed(event -> {
            node.setUserData(new double[]{event.getSceneX(), event.getSceneY(), node.getCenterX(), node.getCenterY()});
        });

        node.setOnMouseDragged(event -> {
            double[] userData = (double[]) node.getUserData();
            double offsetX = event.getSceneX() - userData[0];
            double offsetY = event.getSceneY() - userData[1];
            node.setCenterX(userData[2] + offsetX);
            node.setCenterY(userData[3] + offsetY);

            for (Line connection : connections) {
                if (connection.getStartX() == userData[2] && connection.getStartY() == userData[3]) {
                    connection.setStartX(node.getCenterX());
                    connection.setStartY(node.getCenterY());
                } else if (connection.getEndX() == userData[2] && connection.getEndY() == userData[3]) {
                    connection.setEndX(node.getCenterX());
                    connection.setEndY(node.getCenterY());
                }
            }
        });
    }

    private String getRandomColor() {
        return String.format("#%02X%02X%02X", random.nextInt(256), random.nextInt(256), random.nextInt(256));
    }
}
