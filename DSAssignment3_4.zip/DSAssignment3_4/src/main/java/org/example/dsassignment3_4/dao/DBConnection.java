package org.example.dsassignment3_4.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mariadb://localhost:3306/social_network";
    private static final String USER = "test_user";
    private static final String PASSWORD = "your_password";
    private static final String password = "AVNS_BDy8oE5B-_bx9mooV7w";
    private static Connection connection = null;

    // Method to make  connection
    public static Connection getConnection() {
        if (connection == null) {
            try {
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            } catch (SQLException e) {
                System.err.println("Connection failed: " + e.getMessage());
            }
        }
        return connection;
    }

    public static Connection getConnection2() {

        if (connection == null) {
            try {
                // Load the MySQL JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");
                String url ="jdbc:mysql://localhost::3306/social_network";
                connection = DriverManager.getConnection(url, "root", "1234");
            } catch (SQLException e) {
                System.err.println("Connection failed: " + e.getMessage());
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
        return connection;
    }

    public static Connection getMySQLConnection() {
        if (connection == null) {
            try {
                // Load the MySQL JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Build MySQL connection string with parameters
                String databaseName = "social_network";
                String url = "jdbc:mysql://ds-project-social-networks-hasnatrasool163-94d7.b.aivencloud.com:27373/social_network?sslmode=require";

                // Establish the connection for MySQL
                String userName = "avnadmin";
                connection = DriverManager.getConnection(url, userName, password);
                System.out.println("Connection established to MySQL database: " + databaseName);
            } catch (SQLException | ClassNotFoundException e) {
                System.err.println("MySQL Connection failed: " + e.getMessage());
            }
        }
        return connection;
    }


    // close connection
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Database connection closed.");
            } catch (SQLException e) {
                System.err.println("Error closing connection: " + e.getMessage());
            }
        }
    }
}
