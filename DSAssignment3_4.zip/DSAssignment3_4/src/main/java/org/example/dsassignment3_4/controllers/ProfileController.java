package org.example.dsassignment3_4.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import org.example.dsassignment3_4.dao.DBConnection;
import org.example.dsassignment3_4.service.SessionManager;
import org.example.dsassignment3_4.utilities.UtilityMethods;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProfileController {

    @FXML
    private Circle statusCircle;
    @FXML
    private Label usernameLabel;
    @FXML
    private Label totalFriendsLabel;
    @FXML
    private Label emailLabel;
    @FXML
    private Label dobLabel;
    @FXML
    private Label genderLabel;
    @FXML
    private Label locationLabel;
    @FXML
    private Button visualizeButton;

    private int user_id = SessionManager.getInstance().getUserId();

    @FXML
    private Button addFriendButton;

    @FXML
    void visualizeConnections(){
      UtilityMethods.switchToScene(statusCircle,"UserConnections");
    }


    public void setStatus(boolean isOnline) {
        statusCircle.setFill(isOnline ? Color.GREEN : Color.RED);
    }

    @FXML
    public void initialize(){
        usernameLabel.setText(SessionManager.getInstance().getUsername());
        fetchTotalFriends();
        loadProfileDetails();
        setStatus(SessionManager.getInstance().getStatus() == 1);

    }


    public void loadProfileDetails(){
        try{
            Connection conn = DBConnection.getConnection();
            String sql = "select email , dob , gender from userinfo where user_id=?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setInt(1,user_id);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                String email = rs.getString("email");
                String dob = rs.getString("dob");
                String gender = rs.getString("gender");

              emailLabel.setText(email);
              dobLabel.setText(dob);
              genderLabel.setText(gender);
            }

        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
    @FXML
    private void editProfile() {
       UtilityMethods.switchToScene("UserProfile");
    }

    @FXML
    private void logout() {
        System.exit(0);
    }

    @FXML
    private void setupSecurityQuestions(){
       UtilityMethods.switchToScene("SetupSecurityQuestions");
    }


    public void fetchTotalFriends() {
        System.out.println("fecthing for "+ user_id);
        String query = "SELECT COUNT(*) AS total_friends FROM friendships WHERE status =? and user2_id =? " +
                "or status =? and user1_id= ?;";

        try {Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, "ACCEPTED");
            statement.setInt(2, user_id);
            statement.setString(3, "ACCEPTED");
            statement.setInt(4, user_id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int totalFriends = resultSet.getInt("total_friends");
                totalFriendsLabel.setText(String.valueOf(totalFriends));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
