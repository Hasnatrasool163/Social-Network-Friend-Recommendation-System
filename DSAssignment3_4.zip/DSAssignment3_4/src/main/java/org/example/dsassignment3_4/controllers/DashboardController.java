package org.example.dsassignment3_4.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

import javafx.stage.Modality;
import javafx.stage.Stage;
import org.example.dsassignment3_4.model.Post;
import org.example.dsassignment3_4.model.User;
import org.example.dsassignment3_4.service.PostService;
import org.example.dsassignment3_4.service.SearchService;
import org.example.dsassignment3_4.service.SessionManager;
import org.example.dsassignment3_4.utilities.UtilityMethods;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class DashboardController {

    @FXML
    private Button logoutButton2;
    @FXML
    private TextField searchField;
    @FXML
    private TextArea postTextArea;
    @FXML
    private Button postButton, clearButton ,logoutButton,notificationsButton;
    @FXML
    private Pane centerPane;
    @FXML
    private VBox notificationsList;
    @FXML
    private VBox searchResultsVBox;
    @FXML
    private Label likes;

    private Queue<Post> postQueue = new LinkedList<>();
    private int userId = SessionManager.getInstance().getUserId();

    @FXML
    public void initialize() {
        loadPosts();
        searchResultsVBox.setVisible(false);
        searchField.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue && searchField.getText().trim().isEmpty()) {
                hideSearchResults();
            }
        });
    }

    private void loadPosts() {
        try {
            postQueue= fetchPostsFromDatabase();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        for (Post po : postQueue) {
            handlePostAction(po.getContent(),po.getUsername(),false,po.getTimestamp());
        }
    }

    private double nextPostY = 240;

    static  DashboardController instance;

    public static  DashboardController getInstance(){
        if(instance==null){
            return new DashboardController();
        }
        return instance;
    }

    public void handlePostAction(String Content, String username, boolean save, LocalDateTime timestamp) {
        String postContent ;
        if(Content.isEmpty()){
        postContent = postTextArea.getText().trim();
        } else if (Content.equals("javafx.event.ActionEvent[source=Button[id=postButton, styleClass=button]'Post']")) {
            return;
        } else{
            postContent = Content;
        }
        if (!postContent.isEmpty() || !postContent.isBlank()) {
            // Create the main container for the post
            VBox postContainer = new VBox();
            postContainer.setStyle("-fx-background-color: white; -fx-padding: 10; -fx-border-color: #d3d3d3; -fx-border-width: 1; -fx-spacing: 10;");
            postContainer.setPrefWidth(750);

            // Header with profile picture and username
            HBox postHeader = new HBox(10);
            ImageView profileImage = new ImageView(new Image(Objects.requireNonNull(getClass().getResourceAsStream("/Images/logo.png"))));
            profileImage.setFitWidth(40);
            profileImage.setFitHeight(40);
            Label usernameLabel = new Label(username);
            usernameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 18; -fx-fill: white");
            postHeader.getChildren().addAll(profileImage, usernameLabel);

            Label postContentLabel = new Label(postContent);
            postContentLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 18");
            postContentLabel.setWrapText(true);

            HBox actionButtons = new HBox(10);
            Button likeButton = new Button("Like");
            likes = new Label();
            Label time = new Label(timestamp.format(DateTimeFormatter.ISO_DATE));
            likes.setStyle("-fx-font-weight: bold; -fx-font-size: 18;");
            time.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");
            for (Post post1 : postQueue) {
            likeButton.setOnAction(event -> handleLikeAction(likeButton, post1.getPostId(), likes));
            likes.setText(String.valueOf(post1.getLikes()));
            }
            actionButtons.getChildren().addAll(likeButton,likes,time);

            postContainer.getChildren().addAll(postHeader, postContentLabel, actionButtons);

            postContainer.setLayoutX(10);
            postContainer.setLayoutY(nextPostY);
            nextPostY += 150;
            centerPane.getChildren().add(postContainer);
            if(save) savePostToDatabase(userId,postContent);

            postTextArea.clear();
        }
    }


    private void handleLikeAction(Button likeButton, int postId, Label likesCountLabel) {
        if (likeButton.getText().equals("Like")) {
            if (incrementLikes(postId)) {
                int currentLikes = Integer.parseInt(likesCountLabel.getText());
                likesCountLabel.setText(String.valueOf(currentLikes + 1));
                likeButton.setText("Liked");
                likeButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;");
            }
        } else {
            likeButton.setText("Like");
            likeButton.setStyle("-fx-background-color: #e0e0e0; -fx-text-fill: black; -fx-font-weight: normal;");
        }
    }

    public void handleClearAction() {
        postTextArea.clear();
    }

    private void savePostToDatabase(int userId, String postText) {
        PostService.savePostToDatabase(userId, postText);
    }

    private Queue<Post> fetchPostsFromDatabase() throws SQLException {
       return PostService.fetchPostsFromDatabase();
    }

        @FXML
    private void handleNotificationsNavigation() {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/NotificationsDialog.fxml"));
                VBox notificationDialog = loader.load();

                Stage dialogStage = new Stage();
                dialogStage.setTitle("Notifications");
                dialogStage.setScene(new Scene(notificationDialog));

                NotificationDialogController controller = loader.getController();
                controller.setDialogStage(dialogStage);

                dialogStage.showAndWait();
                dialogStage.centerOnScreen();
                dialogStage.alwaysOnTopProperty();
            } catch (Exception e) {
                e.printStackTrace();
            }
    }

    @FXML
    private void handleMyProfileNavigation(){
        UtilityMethods.switchToScene("Profile");
    }

    @FXML
    private void handleAboutMeNavigation(){
        UtilityMethods.switchToScene("CompleteProfile");
    }
    @FXML
    private void handleSeeFriendsNavigation() {
        UtilityMethods.switchToScene("Friends");
    }

    @FXML
    private void handleSuggestionsNavigation() {
       UtilityMethods.switchToScene("Recommendations");
    }

    @FXML
    private void handleFindFriends(){
      UtilityMethods.switchToScene("FindFriends");
    }


    @FXML
    private void navigateToCreatePost() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/CreatePost.fxml"));
            Parent createPostRoot = loader.load();

            CreatePostController createPostController = loader.getController();
            createPostController.setDashboardController(this);

            Stage stage = new Stage();
            stage.setScene(new Scene(createPostRoot));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Create New Post");
            stage.showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void navigateToRefresh() {
        loadPosts();
        UtilityMethods.showPopup("Application Refresh!");
    }


    public void showMutualFriends(){
      UtilityMethods.switchToScene("MutualFriends");
    }

    public void setUserOffline(){
        SessionManager.getInstance().setStatus(0);
    }

    public void handleLogout() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setContentText("Are you sure want to logout?");
        alert.setTitle("Logout");
        alert.setHeaderText("Want to Exit?");
        if(alert.showAndWait().orElse(ButtonType.CANCEL) ==ButtonType.OK){
            setUserOffline();
        System.exit(0);
        }
    }

    public void AddFriend(ActionEvent event) {
        UtilityMethods.switchToScene("AddFriend");
    }

    public void handlePostAction(ActionEvent event) {
        handlePostAction("",SessionManager.getInstance().getUsername(),true,LocalDateTime.now());
        savePostToDatabase(userId,event.toString());
    }

    @FXML
    private void handleSearchAction() {
        String searchText = searchField.getText().trim();

        if (!searchText.isEmpty()) {
            System.out.println("Searching for: " + searchText);
            List<User> searchResults = searchUsersByUsername(searchText);
            displaySearchResults(searchResults);
        } else {
            System.out.println("Search field is empty.");
            hideSearchResults();
        }
    }

    private List<User> searchUsersByUsername(String username) {
        return SearchService.searchUsersByUsername(username);
    }

    private void displaySearchResults(List<User> users) {
        searchResultsVBox.getChildren().clear(); // Clear previous results

        if (users.isEmpty()) {
            Label noResultsLabel = new Label("No users found.");
            searchResultsVBox.getChildren().add(noResultsLabel);
            return;
        }

        for (User user : users) {
            Button userButton = new Button(user.getUsername());
            userButton.setOnAction(event -> {
                System.out.println("Selected user: " + user.getUsername());
            });
            userButton.setOnAction(event -> openUserProfile(user.getId()));
            userButton.setPrefWidth(searchResultsVBox.getPrefWidth());
            searchResultsVBox.getChildren().add(userButton);
        }
        searchResultsVBox.setVisible(true);
    }

    private void openUserProfile(int userId) {

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ViewProfile.fxml"));
            Parent root = loader.load();

            ViewProfileController controller = loader.getController();
            controller.loadProfileDetails(userId);

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void hideSearchResults(){
        searchResultsVBox.setVisible(false);
    }

    private boolean incrementLikes(int postId) {
        return PostService.incrementLikes(userId, postId);
    }


}
