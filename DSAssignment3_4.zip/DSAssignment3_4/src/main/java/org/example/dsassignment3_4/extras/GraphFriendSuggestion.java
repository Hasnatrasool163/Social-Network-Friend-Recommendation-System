package org.example.dsassignment3_4.extras;

import org.example.dsassignment3_4.model.SuggestedFriend;

import java.util.*;

public class GraphFriendSuggestion {

    private Map<Integer, List<Integer>> graph;
    private Map<Integer, String> hobbies;
    private Map<Integer, String> location;
    private Map<Integer, Integer> age;

    public GraphFriendSuggestion() {
        graph = new HashMap<>();
        hobbies = new HashMap<>();
        location = new HashMap<>();
        age = new HashMap<>();
        loadDummyData();
    }

    public void loadDummyData() {
        graph.put(1, new ArrayList<>(Arrays.asList(2, 3)));
        graph.put(2, new ArrayList<>(Arrays.asList(1, 4)));
        graph.put(3, new ArrayList<>(Arrays.asList(1, 5)));
        graph.put(4, new ArrayList<>(List.of(2)));
        graph.put(5, new ArrayList<>(List.of(3)));

        hobbies.put(1, "Reading, Music");
        hobbies.put(2, "Music, Sports");
        hobbies.put(3, "Reading, Sports");
        hobbies.put(4, "Music, Movies");
        hobbies.put(5, "Movies, Reading");

        location.put(1, "New York");
        location.put(2, "Los Angeles");
        location.put(3, "New York");
        location.put(4, "Chicago");
        location.put(5, "Los Angeles");

        age.put(1, 25);
        age.put(2, 30);
        age.put(3, 28);
        age.put(4, 35);
        age.put(5, 22);
    }

    public List<Integer> getFriendsOfFriends(int userId) {
        Set<Integer> visited = new HashSet<>();
        List<Integer> friendsOfFriends = new ArrayList<>();

        Queue<Integer> queue = new LinkedList<>();
        queue.add(userId);
        visited.add(userId);

        while (!queue.isEmpty()) {
            int current = queue.poll();

            for (int neighbor : graph.getOrDefault(current, Collections.emptyList())) {
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);

                    if (!graph.get(userId).contains(neighbor)) {
                        friendsOfFriends.add(neighbor);
                    } else {
                        queue.add(neighbor);
                    }
                }
            }
        }

        return friendsOfFriends;
    }

    public List<SuggestedFriend> getSuggestedFriends(int userId) {
        List<SuggestedFriend> suggestions = new ArrayList<>();
        List<Integer> friendsOfFriends = getFriendsOfFriends(userId);

        for (int friendId : friendsOfFriends) {
            String hobbiesData = hobbies.get(friendId);
            String locationData = location.get(friendId);
            int ageData = age.get(friendId);

            double score = calculateScore(userId, friendId, hobbiesData, locationData, ageData);

            suggestions.add(new SuggestedFriend(friendId, "User" + friendId, score));
        }

        suggestions.sort((a, b) -> Double.compare(b.getScore(), a.getScore()));

        return suggestions;
    }

    private double calculateScore(int userId, int friendId, String hobbies, String location, int age) {
        double mutualFriendWeight = 0.5;
        double hobbiesWeight = 0.25;
        double locationWeight = 0.15;
        double ageProximityWeight = 0.1;

        int mutualFriends = graph.get(userId).stream().filter(graph.get(friendId)::contains).toList().size();
        boolean sharedHobbies = hobbies.equalsIgnoreCase(getUserHobbies(userId));
        boolean locationMatch = location.equalsIgnoreCase(getUserLocation(userId));
        boolean ageProximity = Math.abs(age - getUserAge(userId)) <= 5;

        return (mutualFriendWeight * mutualFriends) +
                (hobbiesWeight * (sharedHobbies ? 1 : 0)) +
                (locationWeight * (locationMatch ? 1 : 0)) +
                (ageProximityWeight * (ageProximity ? 1 : 0));
    }

    private String getUserHobbies(int userId) {
        return hobbies.getOrDefault(userId, "");
    }

    private String getUserLocation(int userId) {
        return location.getOrDefault(userId, "");
    }

    private int getUserAge(int userId) {
        return age.getOrDefault(userId, 0);
    }

    public static void main(String[] args) {
        GraphFriendSuggestion gfs = new GraphFriendSuggestion();

        List<SuggestedFriend> suggestions = gfs.getSuggestedFriends(2);
        System.out.println("Suggestions for User 1:");
        for (SuggestedFriend suggestion : suggestions) {
            System.out.println(suggestion.getUsername() + " - Score: " + suggestion.getScore());
        }
    }
}
