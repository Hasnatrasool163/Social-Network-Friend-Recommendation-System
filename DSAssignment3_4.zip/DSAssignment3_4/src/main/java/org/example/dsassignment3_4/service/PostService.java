package org.example.dsassignment3_4.service;

import org.example.dsassignment3_4.dao.DBConnection;
import org.example.dsassignment3_4.model.Post;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.Queue;

public class PostService {

    public static void savePostToDatabase(int userId, String postText) {
        String insertQuery = "INSERT INTO posts (user_id, post_text) VALUES (?, ?)";
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement statement = connection.prepareStatement(insertQuery);

            statement.setInt(1, userId);
            statement.setString(2, postText);

            statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static Queue<Post> fetchPostsFromDatabase() throws SQLException {
        Queue<Post> posts = new LinkedList<>();
        String selectQuery = "SELECT p.post_id, p.post_text, p.likes, u.id, u.username, p.created_at " +
                "FROM posts p " +
                "JOIN users u ON p.user_id = u.id " +
                "ORDER BY p.created_at ASC";

        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement statement = connection.prepareStatement(selectQuery);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Post post = new Post(
                        resultSet.getInt("post_id"),
                        resultSet.getInt("id"),
                        resultSet.getString("username"),
                        resultSet.getString("post_text"),
                        resultSet.getTimestamp("created_at").toLocalDateTime(),
                        resultSet.getInt("likes"));
                posts.add(post);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        return posts;
    }

    public static boolean incrementLikes(int userId, int postId) {
        String checkQuery = "SELECT COUNT(*) FROM post_likes WHERE post_id = ? AND user_id = ?";
        String insertQuery = "INSERT INTO post_likes (post_id, user_id) VALUES (?, ?)";
        String updateQuery = "UPDATE posts SET likes = likes + 1 WHERE post_id = ?";

        try {Connection connection = DBConnection.getConnection();
            PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
            checkStmt.setInt(1, postId);
            checkStmt.setInt(2, userId);
            ResultSet resultSet = checkStmt.executeQuery();
            if (resultSet.next() && resultSet.getInt(1) > 0) {
                return false;
            }

            PreparedStatement insertStmt = connection.prepareStatement(insertQuery);
            insertStmt.setInt(1, postId);
            insertStmt.setInt(2, userId);
            insertStmt.executeUpdate();

            PreparedStatement updateStmt = connection.prepareStatement(updateQuery);
            updateStmt.setInt(1, postId);
            updateStmt.executeUpdate();

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
