package org.example.dsassignment3_4.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import org.example.dsassignment3_4.dao.DBConnection;
import org.example.dsassignment3_4.service.FriendsService;
import org.example.dsassignment3_4.service.SessionManager;
import org.example.dsassignment3_4.service.UserService;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ViewProfileController {

    @FXML
    private Circle statusCircle;
    @FXML
    private Label usernameLabel;
    @FXML
    private Label totalFriendsLabel;
    @FXML
    private Label emailLabel;
    @FXML
    private Label dobLabel;
    @FXML
    private Label genderLabel;
    @FXML
    private Label locationLabel;
    @FXML
    private Button quickMessageButton;
    @FXML
    private Button addFriendButton;

    private int user_id = SessionManager.getInstance().getUserId();

    private String friendUsername ;
    private int friendId ;


    boolean is_private = SessionManager.getInstance().isIs_private();

    public void handleAddFriend() {
        FriendsService.handleAddFriend(friendUsername);
    }

    public void setStatus(boolean isOnline) {
        statusCircle.setFill(isOnline ? Color.GREEN : Color.RED);
    }

    @FXML
    public void initialize(){
        fetchTotalFriends();
        setStatus(SessionManager.getInstance().getStatus() == 1);
        quickMessageButton.setOnAction(e -> openChat());

    }

    private void openChat() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/MessageView.fxml"));
            Parent chatRoot = loader.load();

            MessageController messageController = loader.getController();
            messageController.loadChat(friendId,friendUsername);

            Stage chatStage = new Stage();
            chatStage.setTitle("Chat");
            chatStage.setScene(new Scene(chatRoot));
            chatStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void logout() {
        System.exit(0);

    }

    public void loadProfileDetails(int userId) {
        friendId = userId;
        if(is_private){
            emailLabel.setText("******");
            dobLabel.setText("**/**/**");
            genderLabel.setText("******");
        }
        else {
            System.out.println("Searching for userid :" + userId);
            try {
                Connection conn = DBConnection.getConnection();
                String sql = " SELECT email, dob, gender from userinfo WHERE user_id = ?";
                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setInt(1, friendId);
                ResultSet rs = statement.executeQuery();
                if (rs.next()) {
                    emailLabel.setText(rs.getString("email"));
                    dobLabel.setText(rs.getString("dob"));
                    genderLabel.setText(rs.getString("gender"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        friendUsername = UserService.loadUsername(friendId);
        usernameLabel.setText(friendUsername);

    }

    public void fetchTotalFriends() {
        String query = "SELECT COUNT(*) AS total_friends FROM friendships WHERE user1_id = ? or user2_id=? and status =?";
        try {Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, friendId);
            statement.setInt(2, friendId);
            statement.setString(3, "ACCEPTED");
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int totalFriends = resultSet.getInt("total_friends");
                totalFriendsLabel.setText(String.valueOf(totalFriends));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
