package org.example.dsassignment3_4.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.dsassignment3_4.dao.DBConnection;
import org.example.dsassignment3_4.service.SessionManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class NotificationDialogController {

    @FXML
    private VBox notificationBox;
    @FXML
    private Button markAsReadButton;

    private Stage dialogStage;

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    private final ObservableList<String> notifications = FXCollections.observableArrayList();

    int userId = SessionManager.getInstance().getUserId();

    public void closeNotification() {
        dialogStage.close();
    }

    @FXML
    public void initialize() {
        loadNotifications();
        setNotificationMessages(notifications);
    }

    public void setNotificationMessages(List<String> messages) {
        notificationBox.getChildren().clear();

        for (String message : messages) {
            Label notificationLabel = new Label(message);
            notificationLabel.setStyle("-fx-font-size: 14px;");
            notificationBox.getChildren().add(notificationLabel);
        }
    }

    private void loadNotifications() {
        notifications.clear();
        try {
            Connection connection = DBConnection.getConnection();
            String query = "SELECT content FROM notifications WHERE user_id = ? AND status = 'unread' ORDER BY created_at DESC";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String content = rs.getString("content");
                notifications.add(content);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void handleMarkAsRead(){
        try {
            Connection connection = DBConnection.getConnection();
            String query = "update notifications set status =? where id= ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, "read");
            stmt.setInt(2, userId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
