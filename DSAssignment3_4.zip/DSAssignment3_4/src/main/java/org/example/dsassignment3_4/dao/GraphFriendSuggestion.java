package org.example.dsassignment3_4.dao;

import org.example.dsassignment3_4.model.ScoreReport;
import org.example.dsassignment3_4.model.SuggestedFriend;

import java.sql.*;
import java.util.*;

public class GraphFriendSuggestion {

    private  Map<Integer, List<Integer>> graph;

    public GraphFriendSuggestion() {
        graph = new HashMap<>();
        loadGraph();
    }

    public void loadGraph() {
        String query = "SELECT user1_id, user2_id FROM friendships";

        try {Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                int user1 = rs.getInt("user1_id");
                int user2 = rs.getInt("user2_id");

                graph.computeIfAbsent(user1, k -> new ArrayList<>()).add(user2);
                graph.computeIfAbsent(user2, k -> new ArrayList<>()).add(user1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // BFS to find friends of friends
    public  List<Integer> getFriendsOfFriends(int userId) {
        Set<Integer> visited = new HashSet<>();
        List<Integer> friendsOfFriends = new ArrayList<>();

        Queue<Integer> queue = new LinkedList<>();
        queue.add(userId);
        visited.add(userId);

        while (!queue.isEmpty()) {
            int current = queue.poll();

            for (int neighbor : graph.getOrDefault(current, Collections.emptyList())) {
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);

                    // Add friends of friends
                    if (!graph.get(userId).contains(neighbor)) {
                        friendsOfFriends.add(neighbor);
                    } else {
                        queue.add(neighbor);
                    }
                }
            }
        }

        return friendsOfFriends;
    }

    public  List<SuggestedFriend> getSuggestedFriends(int userId) {
        List<SuggestedFriend> suggestions = new ArrayList<>();
        List<Integer> friendsOfFriends = getFriendsOfFriends(userId);

        String query = """
            SELECT
                u.id AS suggested_friend_id,
                u.username,
                cp.hobbies,
                cp.location,
                cp.education,
                cp.extras,
                cp.age
            FROM users u
            JOIN completeProfile cp ON u.id = cp.user_id
            WHERE u.id = ?
        """;

        try {Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);

            for (int friendId : friendsOfFriends) {
                stmt.setInt(1, friendId);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    int suggestedId = rs.getInt("suggested_friend_id");
                    String username = rs.getString("username");
                    String hobbies = rs.getString("hobbies");
                    String location = rs.getString("location");
                    String education = rs.getString("education");
                    String extras = rs.getString("extras");
                    int age = rs.getInt("age");

                   ScoreReport report = calculateScore(userId, friendId, hobbies, education, location, extras, age);

                    suggestions.add(new SuggestedFriend(suggestedId, username, report.getScore()));

                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        suggestions.sort((a, b) -> Double.compare(b.getScore(), a.getScore()));

        return suggestions;
    }

    private ScoreReport calculateScore(int userId, int friendId, String hobbies,String education, String location,String extras, int age) {
        double mutualFriendWeight = 0.35;
        double hobbiesWeight = 0.15;
        double educationWeight = 0.15;
        double ageProximityWeight = 0.15;
        double locationWeight = 0.1;
        double extrasWeight = 0.1;

        // mutual friends logic:
        // graph.get(userId) get direct friends of userId.
        // graph.get(friendId) get list of direct friends of friendId.

        int maxMutualFriends = graph.values().stream().mapToInt(List::size).max().orElse(1);
        int mutualFriends = graph.get(userId).stream().filter(graph.get(friendId)::contains).toList().size();
        boolean sharedHobbies = hobbies.equalsIgnoreCase(getUserHobbies(userId));
        boolean locationMatch = location.equalsIgnoreCase(getUserLocation(userId));
        boolean educationMatch = education.equalsIgnoreCase(getUserEducation(userId));
        boolean ageProximity = Math.abs(age - getUserAge(userId)) <= 5;
        double extraScore = 0.1;
        if (extras != null && !extras.isEmpty()) {
            extraScore = extras.equalsIgnoreCase(getUserExtras(userId)) ? 1 : 0;
        }

        double score = (mutualFriendWeight * (mutualFriends / (double) maxMutualFriends)) +
                (hobbiesWeight * (sharedHobbies ? 1 : 0)) +
                (locationWeight * (locationMatch ? 1 : 0)) +
                (educationWeight * (educationMatch ? 1 : 0)) +
                (ageProximityWeight * (ageProximity ? 1 : 0)) +
                (extrasWeight * extraScore);

        StringBuilder report = new StringBuilder();
        report.append("---- Detailed Analysis Report ----\n")
                .append("User ID: ").append(userId).append("\n")
                .append("Friend ID: ").append(friendId).append("\n")
                .append("Mutual Friends: ").append(mutualFriends).append(" / ").append(maxMutualFriends).append("\n")
                .append("Shared Hobbies: ").append(sharedHobbies ? "Yes" : "No").append("\n")
                .append("Location Match: ").append(locationMatch ? "Yes" : "No").append("\n")
                .append("Education Match: ").append(educationMatch ? "Yes" : "No").append("\n")
                .append("Age Proximity (within 5 years): ").append(ageProximity ? "Yes" : "No").append("\n")
                .append("Extras Match: ").append(extraScore == 1 ? "Yes" : "No").append("\n")
                .append("\nContribution Breakdown:\n")
                .append("Mutual Friends Weight: ").append(mutualFriendWeight).append(" | Contribution: ").append(mutualFriendWeight * (mutualFriends / (double) maxMutualFriends)).append("\n")
                .append("Hobbies Weight: ").append(hobbiesWeight).append(" | Contribution: ").append(hobbiesWeight * (sharedHobbies ? 1 : 0)).append("\n")
                .append("Location Weight: ").append(locationWeight).append(" | Contribution: ").append(locationWeight * (locationMatch ? 1 : 0)).append("\n")
                .append("Education Weight: ").append(educationWeight).append(" | Contribution: ").append(educationWeight * (educationMatch ? 1 : 0)).append("\n")
                .append("Age Proximity Weight: ").append(ageProximityWeight).append(" | Contribution: ").append(ageProximityWeight * (ageProximity ? 1 : 0)).append("\n")
                .append("Extras Weight: ").append(extrasWeight).append(" | Contribution: ").append(extrasWeight * extraScore).append("\n")
                .append("Final Score: ").append(score).append("\n")
                .append("----------------------------------");

        System.out.println(report);
        return new ScoreReport(score, report.toString());
    }

        // fetch user hobbies
    private  String getUserHobbies(int userId) {
        String query = "SELECT hobbies FROM completeProfile WHERE user_id = ?";
        try {Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("hobbies");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "";
    }

    private  String getUserLocation(int userId) {
        String query = "SELECT location FROM completeProfile WHERE user_id = ?";
        try {Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("location");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "";
    }

    private  String getUserEducation(int userId) {
        String query = "SELECT education FROM completeProfile WHERE user_id = ?";
        try {Connection conn = DBConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(query);

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("education");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "";
    }

    private  String getUserExtras(int userId) {
        String query = "SELECT extras FROM completeProfile WHERE user_id = ?";
        try {Connection conn = DBConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(query);

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("extras");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "";
    }

    private  int getUserAge(int userId) {
        String query = "SELECT age FROM completeProfile WHERE user_id = ?";
        try {Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("age");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static void main(String[] args) {
        GraphFriendSuggestion friendSuggestion = new GraphFriendSuggestion();
        friendSuggestion.loadGraph();
        System.out.println(friendSuggestion.getSuggestedFriends(4));
    }
}
