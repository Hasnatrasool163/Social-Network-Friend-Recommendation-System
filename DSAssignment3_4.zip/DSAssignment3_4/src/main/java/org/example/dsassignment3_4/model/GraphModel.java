package org.example.dsassignment3_4.model;

import java.util.*;

public class GraphModel {

    // Adjacency list
    private final Map<Integer, List<Integer>> adjacencyList;

    public GraphModel() {
        this.adjacencyList = new HashMap<>();
    }

    // Add an edge (friendship) between two users
    public void addEdge(int user1, int user2) {
        adjacencyList.computeIfAbsent(user1, k -> new ArrayList<>()).add(user2);
        adjacencyList.computeIfAbsent(user2, k -> new ArrayList<>()).add(user1);
    }

    // Remove an edge (friendship) between two users
    public void removeEdge(int user1, int user2) {
        adjacencyList.getOrDefault(user1, new ArrayList<>()).remove(Integer.valueOf(user2));
        adjacencyList.getOrDefault(user2, new ArrayList<>()).remove(Integer.valueOf(user1));
    }

    //  list of friends for a user
    public List<Integer> getFriends(int userId) {
        return adjacencyList.getOrDefault(userId, Collections.emptyList());
    }

    // if two users are friends
    public boolean areFriends(int user1, int user2) {
        return adjacencyList.getOrDefault(user1, Collections.emptyList()).contains(user2);
    }

    // Print
    public void printGraph() {
        for (Map.Entry<Integer, List<Integer>> entry : adjacencyList.entrySet()) {
            System.out.println("User " + entry.getKey() + " -> " + entry.getValue());
        }
    }
}
