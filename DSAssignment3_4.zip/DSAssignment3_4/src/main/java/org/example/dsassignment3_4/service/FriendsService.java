package org.example.dsassignment3_4.service;

import org.example.dsassignment3_4.dao.DBConnection;
import org.example.dsassignment3_4.model.FriendShip;
import org.example.dsassignment3_4.model.Status;
import org.example.dsassignment3_4.utilities.UtilityMethods;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class FriendsService {

    public List<FriendShip> loadData() throws SQLException {
        Connection connection = DBConnection.getConnection();
        String query = """
            select * from friendships;
            """;
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();

        List<FriendShip> friendShips = new ArrayList<>();
        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            int uid = resultSet.getInt("user1_id");
            int uid2 = resultSet.getInt("user2_id");
            double score = resultSet.getDouble("score");
            Status status = Status.valueOf(resultSet.getString("status"));
            int mutualFriends = resultSet.getInt("mutual_friends");

            FriendShip friendShip = new FriendShip(id,uid,uid2,score,status,mutualFriends);
            friendShips.add(friendShip);
        }
        System.out.println(friendShips);
        return friendShips;
    }

    public List<String> getFriends(String username) throws SQLException {
        List<String> friends = new ArrayList<>();
        Connection connection = DBConnection.getConnection();
        String query = """
            SELECT u.username 
            FROM friendships f
            JOIN users u ON (f.user1_id = u.id OR f.user2_id = u.id)
            WHERE (SELECT id FROM users WHERE username = ?) IN (f.user1_id, f.user2_id)
              AND u.username != ?
              AND f.status = 'ACCEPTED'
        """;

        try {PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, username);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                friends.add(resultSet.getString("username"));
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return friends;
    }

    public Map<String, String[]> loadFriendConnections() throws SQLException {
        Map<String, ArrayList<String>> connectionsMap = new HashMap<>();

        String query = "SELECT u1.username AS user1, u2.username AS user2 " +
                "FROM friendships f " +
                "JOIN users u1 ON f.user1_id = u1.id " +
                "JOIN users u2 ON f.user2_id = u2.id " +
                "WHERE f.status = 'accepted'";

        try {Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                String user1 = rs.getString("user1");
                String user2 = rs.getString("user2");

                connectionsMap.putIfAbsent(user1, new ArrayList<>());
                connectionsMap.putIfAbsent(user2, new ArrayList<>());

                connectionsMap.get(user1).add(user2);
                connectionsMap.get(user2).add(user1);
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }

        // Convert Map<String, ArrayList<String>> to Map<String, String[]>
        Map<String, String[]> userConnections = new HashMap<>();
        for (Map.Entry<String, ArrayList<String>> entry : connectionsMap.entrySet()) {
            userConnections.put(entry.getKey(), entry.getValue().toArray(new String[0]));
        }

        return userConnections;
    }

    public static void handleAddFriend(String username) {
        if (username.isBlank()) {
            return;
        }

        int friendId = UserService.loadUserId(username);
        if (friendId == -1) {
            System.out.println("No user found with the username: " + username);
            return;
        }

        int currentUserId = SessionManager.getInstance().getUserId();

        if (isAlreadyFriend(currentUserId, friendId)) {
            System.out.println("You are already friends with this user or a request is pending.");
            return;
        }

        try {Connection conn = DBConnection.getConnection();
            String sql = "INSERT INTO friendships (user1_id, user2_id, status) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, currentUserId);
            stmt.setInt(2, friendId);
            stmt.setString(3, "PENDING");
            stmt.executeUpdate();
            UtilityMethods.showPopup("Friend Request send to : " +username);
            System.out.println("Friend request sent successfully!");
        } catch (SQLException e) {
            System.err.println("An error occurred while sending the friend request: " + e.getMessage());
        }
    }

    private static boolean isAlreadyFriend(int userId, int friendId) {
        String sql = "SELECT * FROM friendships WHERE " +
                "(user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)";

        try {Connection conn = DBConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setInt(2, friendId);
            stmt.setInt(3, friendId);
            stmt.setInt(4, userId);

            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println("Error checking friendship: " + e.getMessage());
            return false;
        }
    }

    public List<String> getFriendRequests(int userId) throws SQLException {
        List<String> friendRequests = new ArrayList<>();
        String query = "SELECT user1_id FROM friendships WHERE user2_id = ? AND status = 'PENDING'";

        try {Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query);

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int user1Id = rs.getInt("user1_id");
                String username = getUsernameById(user1Id);
                friendRequests.add(username);
            }
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }

        return friendRequests;
    }

    public void acceptFriendRequest(int receiverId, int senderId) throws SQLException {
        String updateQuery = "UPDATE friendships SET status = 'ACCEPTED' WHERE (user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)";

        try {Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(updateQuery);
            stmt.setInt(1, senderId);
            stmt.setInt(2, receiverId);
            stmt.setInt(3, receiverId);
            stmt.setInt(4, senderId);
            stmt.executeUpdate();
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }
    }

    public void declineFriendRequest(int receiverId, int senderId) throws SQLException {
        String updateQuery = "UPDATE friendships SET status = 'DECLINED' WHERE (user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)";

        try {Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(updateQuery);
            stmt.setInt(1, senderId);
            stmt.setInt(2, receiverId);
            stmt.setInt(3, receiverId);
            stmt.setInt(4, senderId);
            stmt.executeUpdate();
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }
    }

    private String getUsernameById(int userId) throws SQLException {
        String query = "SELECT username FROM users WHERE id = ?";
        try {Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("username");
            }
            return null;
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }
    }
}
