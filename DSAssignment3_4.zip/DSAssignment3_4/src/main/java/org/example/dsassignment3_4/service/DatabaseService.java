package org.example.dsassignment3_4.service;

import org.example.dsassignment3_4.dao.DBConnection;
import org.example.dsassignment3_4.model.FriendShip;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseService {

    public List<FriendShip> getFriends(String username) throws SQLException {
        List<FriendShip> friendsList = new ArrayList<>();

        String query = """
        SELECT u.username,
               COUNT(mf.user2_id) AS mutualFriends
        FROM friendships f
        JOIN users u ON u.id = f.user2_id
        LEFT JOIN friendships mf ON mf.user1_id = f.user2_id
        AND mf.user2_id IN (
            SELECT f2.user2_id
            FROM friendships f1
            JOIN friendships f2 ON f1.user2_id = f2.user1_id
            WHERE f1.user1_id = (SELECT id FROM users WHERE username = ?)
        )
        WHERE f.user1_id = (SELECT id FROM users WHERE username = ?)
        AND f.status = 'ACCEPTED'
        GROUP BY u.username;
    """;

        try {Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);

            statement.setString(1, username);
            statement.setString(2, username);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String friendName = resultSet.getString("username");
                int mutualFriendsCount = resultSet.getInt("mutualFriends");
                friendsList.add(new FriendShip(friendName, mutualFriendsCount));
            }
        } catch (RuntimeException e) {
                throw new RuntimeException(e);
        }
        return friendsList;
    }

    public List<String> getMutualFriends(String currentUser, String friendName) throws SQLException {
        List<String> mutualFriends = new ArrayList<>();

        String query = """
        SELECT DISTINCT u.username
        FROM users u
        JOIN friendships f1 ON f1.user2_id = u.id
        JOIN friendships f2 ON f2.user2_id = u.id
        WHERE f1.user1_id = (SELECT id FROM users WHERE username = ?)
          AND f2.user1_id = (SELECT id FROM users WHERE username = ?);
    """;

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, currentUser);
            statement.setString(2, friendName);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                mutualFriends.add(resultSet.getString("username"));
            }
        }
        return mutualFriends;
    }

}
