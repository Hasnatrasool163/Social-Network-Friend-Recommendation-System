package org.example.dsassignment3_4.model;

public class ScoreReport {
    private final double score;
    private final String report;

    public ScoreReport(double score, String report) {
        this.score = score;
        this.report = report;
    }

    public double getScore() {
        return score;
    }

    public String getReport() {
        return report;
    }

    @Override
    public String toString() {
        return "Score: " + score + "\n" + report;
    }
}
