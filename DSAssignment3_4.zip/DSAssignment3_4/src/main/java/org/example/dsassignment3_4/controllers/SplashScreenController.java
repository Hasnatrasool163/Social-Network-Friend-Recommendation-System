package org.example.dsassignment3_4.controllers;

import javafx.animation.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.example.dsassignment3_4.utilities.UtilityMethods;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

public class SplashScreenController {

    @FXML
    private Group networkGroup;
    @FXML
    private Label titleLabel;
    @FXML
    private Button letsGoButton;

    private Random random = new Random();
    private Timeline patternSwitcher;

    private static final double CENTER_X = 380;
    private static final double CENTER_Y = 240;
    private static final double RADIUS = 180;

    public void initialize() {
        createNetworkAnimation();
        animateTitle();
        animateTitle2();
        addParticleEffects();
        rotateNetworkGroup();
        autoChangePattern();
    }

    public void switchToRegisterScene() {
        UtilityMethods.switchToScene(titleLabel,"Login");
    }


    private void animateTitle2() {
        Timeline colorAnimation = new Timeline(
                new KeyFrame(Duration.seconds(0),
                        new KeyValue(titleLabel.textFillProperty(), Color.DEEPSKYBLUE)),
                new KeyFrame(Duration.seconds(2),
                        new KeyValue(titleLabel.textFillProperty(), Color.WHITE)),
                new KeyFrame(Duration.seconds(4),
                        new KeyValue(titleLabel.textFillProperty(), Color.ORANGE))
        );
        colorAnimation.setCycleCount(Animation.INDEFINITE);
        colorAnimation.setAutoReverse(true);
        colorAnimation.play();
    }

    private void createNetworkAnimation() {
        networkGroup.getChildren().clear();
        int nodeCount = random.nextInt(10) + 4; // Random number of nodes (4-14)
        List<Circle> nodes = new ArrayList<>();

        for (int i = 0; i < nodeCount; i++) {
            double angle = 2 * Math.PI * i / nodeCount;
            double x = CENTER_X + RADIUS * Math.cos(angle);
            double y = CENTER_Y + RADIUS * Math.sin(angle);

            Circle node = new Circle(10, Color.WHITE);
            node.setEffect(new DropShadow(15, Color.LIGHTBLUE));
            node.setCenterX(x);
            node.setCenterY(y);
            nodes.add(node);
            networkGroup.getChildren().add(node);

            addNodeAnimation(node);
        }

        for (int i = 0; i < nodeCount; i++) {
            for (int j = i + 1; j < nodeCount; j++) {
                Line connection = new Line(
                        nodes.get(i).getCenterX(), nodes.get(i).getCenterY(),
                        nodes.get(j).getCenterX(), nodes.get(j).getCenterY());
                connection.setStroke(Color.LIGHTCYAN);
                connection.setStrokeWidth(1.5);
                connection.setOpacity(0.7);
                networkGroup.getChildren().add(connection);

                connection.startXProperty().bind(nodes.get(i).centerXProperty());
                connection.startYProperty().bind(nodes.get(i).centerYProperty());
                connection.endXProperty().bind(nodes.get(j).centerXProperty());
                connection.endYProperty().bind(nodes.get(j).centerYProperty());
            }
        }
    }

    // top white circle nodes
    private void addNodeAnimation(Circle node) {
        TranslateTransition transition = new TranslateTransition(Duration.seconds(3 + random.nextDouble()), node);
        transition.setByX(random.nextDouble() * 20 - 10);
        transition.setByY(random.nextDouble() * 20 - 10);
        transition.setAutoReverse(true);
        transition.setCycleCount(Animation.INDEFINITE);
        transition.play();
    }

    private void animateTitle() {
        FadeTransition fade = new FadeTransition(Duration.seconds(2), titleLabel);
        fade.setFromValue(0);
        fade.setToValue(1);
        fade.setCycleCount(1);
        fade.setOnFinished(event -> {
            ScaleTransition scale = new ScaleTransition(Duration.seconds(1), titleLabel);
            scale.setByX(0.1);
            scale.setByY(0.1);
            scale.setAutoReverse(true);
            scale.setCycleCount(Animation.INDEFINITE);
            scale.play();
        });
        fade.play();
    }



    private void addParticleEffects() {
        for (int i = 0; i < 30; i++) {
            Circle particle = new Circle(2, Color.WHITE);
            particle.setOpacity(0.5);
            particle.setLayoutX(random.nextDouble() * (800 - 20) + 10);
            particle.setLayoutY(random.nextDouble() * (600 - 20) + 10);
            networkGroup.getChildren().add(particle);

            TranslateTransition transition = new TranslateTransition(Duration.seconds(4 + random.nextDouble()), particle);
            transition.setByX(random.nextDouble() * 100 - 50);
            transition.setByY(random.nextDouble() * 100 - 50);
            transition.setCycleCount(Animation.INDEFINITE);
            transition.setAutoReverse(true);
            transition.play();
        }
    }

    private void rotateNetworkGroup() {
        RotateTransition rotate = new RotateTransition(Duration.seconds(90), networkGroup);
        rotate.setByAngle(360);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setInterpolator(Interpolator.LINEAR);
        rotate.play();
    }

    private void autoChangePattern() {
        patternSwitcher = new Timeline(new KeyFrame(Duration.seconds(5), event -> {
//            createNetworkAnimation();
//            addParticleEffects();
            enableButton();
        }));
        patternSwitcher.setCycleCount(Animation.INDEFINITE);
        patternSwitcher.play();
    }

    private void enableButton() {
        letsGoButton.setDisable(false);
    }
}
