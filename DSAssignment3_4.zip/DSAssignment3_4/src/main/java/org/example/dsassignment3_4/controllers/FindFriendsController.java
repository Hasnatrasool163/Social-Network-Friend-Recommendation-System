package org.example.dsassignment3_4.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ListView;
import javafx.scene.control.ListCell;
import javafx.scene.text.Font;
import javafx.scene.control.Label;
import org.example.dsassignment3_4.dao.DBConnection;
import org.example.dsassignment3_4.model.User;
import org.example.dsassignment3_4.model.UserInfo;
import org.example.dsassignment3_4.service.SessionManager;
import org.example.dsassignment3_4.service.UserService;
import org.example.dsassignment3_4.utilities.UtilityMethods;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FindFriendsController {

    @FXML
    private CheckBox ageGroupCheckBox;

    @FXML
    private CheckBox locationCheckBox;

    @FXML
    private CheckBox hobbiesCheckBox;

    @FXML
    private CheckBox educationCheckBox;

    @FXML
    private Button findButton;

    @FXML
    private ListView<Label> friendsListView;

    private ObservableList<Label> filteredUsersList = FXCollections.observableArrayList();
    List<UserInfo> users;
    private List<UserInfo> cachedUsers = new ArrayList<>();
    private Set<Integer> friendIds = new HashSet<>();


    @FXML
    public void initialize() {
        loadCachedUsers();
        loadFriendRelationships();
        friendsListView.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(Label item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setGraphic(null);
                } else {
                    setGraphic(item);
                }
            }
        });
    }

    @FXML
    private void handleFindButtonClick(ActionEvent event) {
        filteredUsersList.clear();
        users = fetchFilteredUsers();

        for (User user : users) {

                Label userLabel = new Label(user.getUsername());
                userLabel.setFont(new Font(16));
                filteredUsersList.add(userLabel);
        }

        friendsListView.setItems(filteredUsersList);
    }


    private List<UserInfo> fetchFilteredUsers() {
        List<UserInfo> users = new ArrayList<>();
        String query = buildQuery();

        try {Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);

            int paramIndex = 1;
            if (ageGroupCheckBox.isSelected()) {
                preparedStatement.setInt(paramIndex++, 25);
            }
            if (locationCheckBox.isSelected()) {
                preparedStatement.setString(paramIndex++, "New York");
            }
            if (hobbiesCheckBox.isSelected()) {
                preparedStatement.setString(paramIndex++, "%sports%");
            }
            if (educationCheckBox.isSelected()) {
                preparedStatement.setString(paramIndex++, "Bachelor");
            }

            // Execute the query
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                UserInfo user = new UserInfo(
                        resultSet.getString("username"),
                        resultSet.getInt("age"),
                        resultSet.getString("location"),
                        resultSet.getString("education"),
                        resultSet.getString("hobbies")
                );
                users.add(user);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return users;
    }

    private String buildQuery() {
        StringBuilder queryBuilder = new StringBuilder(
                "SELECT u.username, cp.age, cp.location, cp.education, cp.hobbies " +
                        "FROM users u " +
                        "JOIN completeProfile cp ON u.id = cp.user_id " +
                        "WHERE 1=1 "
        );

        if (ageGroupCheckBox.isSelected()) {
            queryBuilder.append("AND cp.age > ? ");
        }
        if (locationCheckBox.isSelected()) {
            queryBuilder.append("AND cp.location = ? ");
        }
        if (hobbiesCheckBox.isSelected()) {
            queryBuilder.append("AND cp.hobbies LIKE ? ");
        }
        if (educationCheckBox.isSelected()) {
            queryBuilder.append("AND cp.education = ? ");
        }

        return queryBuilder.toString();
    }

    @FXML
    void addFriend(){
        String username =friendsListView.getSelectionModel().getSelectedItem().getText();
        handleAddFriend(username);
    }

    private void handleAddFriend(String username) {
        int friendId;
        friendId = getFriendsId(username);
        if (isAlreadyFriend(friendId)) {
            System.out.println("You are already friends with this user!");
            return;
        }
        try {Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO friendships (user1_id, user2_id, status) VALUES (?, ?, 'PENDING')");
            stmt.setInt(1, SessionManager.getInstance().getUserId());
            stmt.setInt(2, friendId);
            stmt.executeUpdate();
            UtilityMethods.showPopup("Friend Request Sent!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

        int getFriendsId(String username){
            return UserService.loadUserId(username);
        }

    private boolean isAlreadyFriend(int userId) {
        return friendIds.contains(userId);
    }


    private void loadCachedUsers() {
        try {Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT u.id, u.username, cp.age, cp.location, cp.education, cp.hobbies " +
                             "FROM users u " +
                             "JOIN completeProfile cp ON u.id = cp.user_id");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                UserInfo user = new UserInfo(
                        rs.getString("username"),
                        rs.getInt("age"),
                        rs.getString("location"),
                        rs.getString("education"),
                        rs.getString("hobbies")
                );
                cachedUsers.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadFriendRelationships() {
        try {Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT user1_id, user2_id " +
                             "FROM friendships " +
                             "WHERE (user1_id = ? OR user2_id = ?) AND status = 'ACCEPTED'");
            stmt.setInt(1, SessionManager.getInstance().getUserId());
            stmt.setInt(2, SessionManager.getInstance().getUserId());
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int user1 = rs.getInt("user1_id");
                int user2 = rs.getInt("user2_id");
                friendIds.add(user1);
                friendIds.add(user2);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
