module org.example.dsassignment3_4 {
    requires javafx.fxml;
    requires fontawesomefx;
    requires java.sql;
    requires org.checkerframework.checker.qual;
    requires mysql.connector.j;
    requires com.sun.jna.platform;
    requires org.controlsfx.controls;
    requires java.desktop;


    opens org.example.dsassignment3_4 to javafx.fxml;
    exports org.example.dsassignment3_4;
    exports org.example.dsassignment3_4.model;
    exports org.example.dsassignment3_4.view to javafx.fxml,javafx.graphics;
    opens org.example.dsassignment3_4.view to javafx.fxml,javafx.graphics;
    exports org.example.dsassignment3_4.splash to javafx.fxml,javafx.graphics;
    opens org.example.dsassignment3_4.model to javafx.fxml;
    exports org.example.dsassignment3_4.controllers;
    opens org.example.dsassignment3_4.controllers to javafx.fxml;
    exports org.example.dsassignment3_4.utilities;
    opens org.example.dsassignment3_4.utilities to javafx.fxml;
    exports org.example.dsassignment3_4.extras;
    opens org.example.dsassignment3_4.extras to javafx.fxml;
    exports org.example.dsassignment3_4.dao;
    opens org.example.dsassignment3_4.dao to javafx.fxml;
}